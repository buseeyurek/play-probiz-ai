/**
 * Play ProBiz — Play ProBiz AI & Masa Rezervasyonu Ön Yüz Mantığı
 *
 * - Anlık (internetsiz) kart parlama ve büyüme animasyonları
 * - 12 imza tatlı kategori filtrelemesi
 * - PyWebView köprüsüyle canlı Gemini 2.5 Flash eşleştirmesi
 * - AI sonucundan tek tıkla doldurulan Masa Rezervasyonu ve Dijital Bilet
 */

const state = {
  games: [],
  desserts: [],
  reservations: [],
  players: "",
  mood: "",
  craving: "",
  selectedGame: "",
  selectedDessert: "",
  activeCategory: "all",
  aiMatchedGame: "",
  aiMatchedDessert: "",
  hasApiKey: false,
  maskedApiKey: "",
  isLoading: false,
  lastSubmittedSignature: "",
  resTimeSlot: "18:00",
  resGuests: "3-4",
  latestTicketCode: "",
};

const els = {
  gamesGrid: document.getElementById("gamesGrid"),
  dessertsGrid: document.getElementById("dessertsGrid"),
  matchBtn: document.getElementById("matchBtn"),
  matchBtnText: document.getElementById("matchBtnText"),
  matchSpinner: document.getElementById("matchSpinner"),
  extraNoteInput: document.getElementById("extraNoteInput"),
  resetSelectionsBtn: document.getElementById("resetSelectionsBtn"),
  selectionSummary: document.getElementById("selectionSummary"),
  statusBanner: document.getElementById("statusBanner"),
  resultPanel: document.getElementById("resultPanel"),
  resultSourceBadge: document.getElementById("resultSourceBadge"),
  resultSlogan: document.getElementById("resultSlogan"),
  resultGameImg: document.getElementById("resultGameImg"),
  resultGameName: document.getElementById("resultGameName"),
  resultGameComment: document.getElementById("resultGameComment"),
  resultDessertImg: document.getElementById("resultDessertImg"),
  resultDessertName: document.getElementById("resultDessertName"),
  resultAllergen: document.getElementById("resultAllergen"),
  reserveFromAiBtn: document.getElementById("reserveFromAiBtn"),
  // Rezervasyon elemanları
  reservationForm: document.getElementById("reservationForm"),
  resTeamInput: document.getElementById("resTeamInput"),
  resDateInput: document.getElementById("resDateInput"),
  resGameSelect: document.getElementById("resGameSelect"),
  resDessertSelect: document.getElementById("resDessertSelect"),
  resNoteInput: document.getElementById("resNoteInput"),
  resBanner: document.getElementById("resBanner"),
  ticketTeam: document.getElementById("ticketTeam"),
  ticketCode: document.getElementById("ticketCode"),
  ticketDateTime: document.getElementById("ticketDateTime"),
  ticketGuests: document.getElementById("ticketGuests"),
  ticketGame: document.getElementById("ticketGame"),
  ticketDessert: document.getElementById("ticketDessert"),
  reservationsList: document.getElementById("reservationsList"),
  resCountBadge: document.getElementById("resCountBadge"),
  // API modal elemanları
  apiStatusDot: document.getElementById("apiStatusDot"),
  apiStatusLabel: document.getElementById("apiStatusLabel"),
  openApiModalBtn: document.getElementById("openApiModalBtn"),
  apiModalOverlay: document.getElementById("apiModalOverlay"),
  closeApiModalBtn: document.getElementById("closeApiModalBtn"),
  apiKeyInput: document.getElementById("apiKeyInput"),
  saveApiKeyBtn: document.getElementById("saveApiKeyBtn"),
  continueOfflineBtn: document.getElementById("continueOfflineBtn"),
  clearApiKeyBtn: document.getElementById("clearApiKeyBtn"),
  currentKeyInfo: document.getElementById("currentKeyInfo"),
  maskedKeyValue: document.getElementById("maskedKeyValue"),
  apiModalFeedback: document.getElementById("apiModalFeedback"),
  configPathHint: document.getElementById("configPathHint"),
};

function hasPyWebView() {
  return Boolean(window.pywebview && window.pywebview.api);
}

/** Bugünün tarihini YYYY-MM-DD formatında döndürür */
function getTodayISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Oyun kartlarını ekrana çizer */
function renderGames() {
  els.gamesGrid.innerHTML = "";
  state.games.forEach((game) => {
    const card = document.createElement("article");
    card.className = `game-card${game.featured ? " featured" : ""}`;
    card.dataset.gameName = game.name;
    card.setAttribute("role", "button");
    card.setAttribute("tabindex", "0");

    card.innerHTML = `
      <span class="card-badge">${game.badge || "Oyun"}</span>
      <span class="card-state-tag" data-tag>Uyumlu</span>
      <div class="game-card-img-wrap">
        <img src="${game.image}" alt="${game.name}" class="game-card-img" />
      </div>
      <div class="game-card-overlay">
        <h3 class="game-title">${game.name}</h3>
        <p class="game-tagline">${game.tagline}</p>
        <span class="game-meta">👥 ${game.players.join(" / ")} Kişi • ⏱ ${game.duration}</span>
        ${game.featured ? '<span class="featured-cta">Oyunu Seç ›</span>' : ""}
      </div>
    `;

    card.addEventListener("click", () => toggleDirectCard("game", game.name));
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggleDirectCard("game", game.name);
      }
    });
    els.gamesGrid.appendChild(card);
  });
}

/** 12 İmza Tatlı kartlarını kategori filtresine göre çizer */
function renderDesserts() {
  els.dessertsGrid.innerHTML = "";
  const visible = state.desserts.filter(
    (d) => state.activeCategory === "all" || d.cravings.includes(state.activeCategory)
  );

  visible.forEach((dessert) => {
    const card = document.createElement("article");
    card.className = "dessert-card";
    card.dataset.dessertName = dessert.name;
    card.setAttribute("role", "button");
    card.setAttribute("tabindex", "0");

    card.innerHTML = `
      <span class="card-state-tag" data-tag>Uyumlu</span>
      <div class="dessert-photo-wrap">
        <img src="${dessert.image}" alt="${dessert.name}" class="dessert-img" />
        ${dessert.note ? `<span class="dessert-note-pill">“${dessert.note}”</span>` : ""}
      </div>
      <div class="dessert-body">
        <h3 class="dessert-name">${dessert.name}</h3>
        <p class="dessert-sub">${dessert.subtitle}</p>
        <div class="dessert-tags">
          ${dessert.cravings.map((c) => `<span class="dessert-tag">${c}</span>`).join("")}
        </div>
      </div>
    `;

    card.addEventListener("click", () => toggleDirectCard("dessert", dessert.name));
    card.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggleDirectCard("dessert", dessert.name);
      }
    });
    els.dessertsGrid.appendChild(card);
  });

  updateInstantHighlights();
}

/** Rezervasyon formundaki oyun ve 12 tatlı açılır listelerini doldurur */
function populateReservationSelects() {
  els.resGameSelect.innerHTML =
    '<option value="Kafede Seçilecek">Kafede Seçeceğiz</option>' +
    state.games.map((g) => `<option value="${g.name}">${g.name}</option>`).join("");

  els.resDessertSelect.innerHTML =
    '<option value="Kafede Seçilecek">Kafede Seçeceğiz</option>' +
    state.desserts.map((d) => `<option value="${d.name}">${d.name}</option>`).join("");
}

/** Doğrudan kart tıklama */
function toggleDirectCard(kind, name) {
  state.aiMatchedGame = "";
  state.aiMatchedDessert = "";
  if (kind === "game") {
    state.selectedGame = state.selectedGame === name ? "" : name;
  } else {
    state.selectedDessert = state.selectedDessert === name ? "" : name;
  }
  updateInstantHighlights();
  updateSelectionSummary();
}

/** İnternet gerektirmeyen anlık neon kart vurgulama animasyonu */
function updateInstantHighlights() {
  const hasGameFilter = Boolean(state.players || state.mood);
  const hasDessertFilter = Boolean(state.craving);
  const anyExactGame = state.games.some(
    (g) =>
      (!state.players || g.players.includes(state.players)) &&
      (!state.mood || g.moods.includes(state.mood))
  );

  document.querySelectorAll(".game-card").forEach((card) => {
    const name = card.dataset.gameName;
    const game = state.games.find((g) => g.name === name);
    const tag = card.querySelector("[data-tag]");
    card.classList.remove("highlighted", "selected", "dimmed");

    if (state.aiMatchedGame && state.aiMatchedGame === name) {
      card.classList.add("selected");
      tag.textContent = "✨ AI Seçimi";
      return;
    }
    if (state.selectedGame) {
      if (state.selectedGame === name) {
        card.classList.add("selected");
        tag.textContent = "✓ Seçildi";
      } else {
        card.classList.add("dimmed");
      }
      return;
    }
    if (hasGameFilter && game) {
      const pOk = !state.players || game.players.includes(state.players);
      const mOk = !state.mood || game.moods.includes(state.mood);
      if (pOk && mOk) {
        card.classList.add("highlighted");
        tag.textContent = "⚡ Tam Uyum";
      } else if (!anyExactGame && ((state.players && pOk) || (state.mood && mOk))) {
        card.classList.add("highlighted");
        tag.textContent = "★ Öneri";
      } else {
        card.classList.add("dimmed");
      }
    }
  });

  document.querySelectorAll(".dessert-card").forEach((card) => {
    const name = card.dataset.dessertName;
    const dessert = state.desserts.find((d) => d.name === name);
    const tag = card.querySelector("[data-tag]");
    card.classList.remove("highlighted", "selected", "dimmed");

    if (state.aiMatchedDessert && state.aiMatchedDessert === name) {
      card.classList.add("selected");
      tag.textContent = "✨ AI Seçimi";
      return;
    }
    if (state.selectedDessert) {
      if (state.selectedDessert === name) {
        card.classList.add("selected");
        tag.textContent = "✓ Seçildi";
      } else {
        card.classList.add("dimmed");
      }
      return;
    }
    if (hasDessertFilter && dessert) {
      if (dessert.cravings.includes(state.craving)) {
        card.classList.add("highlighted");
        tag.textContent = state.craving === "Sürpriz" ? "🎁 Sürpriz" : "💜 Uyumlu";
      } else {
        card.classList.add("dimmed");
      }
    }
  });
}

function updateSelectionSummary() {
  const pills = [];
  if (state.players) pills.push(`👥 ${state.players} Kişi`);
  if (state.mood) pills.push(`⚡ ${state.mood}`);
  if (state.craving) pills.push(`🍰 ${state.craving}`);
  if (state.selectedGame) pills.push(`🎲 Oyun: ${state.selectedGame}`);
  if (state.selectedDessert) pills.push(`🧁 Tatlı: ${state.selectedDessert}`);

  if (pills.length === 0) {
    els.selectionSummary.classList.add("hidden");
    els.selectionSummary.innerHTML = "";
    return;
  }
  els.selectionSummary.classList.remove("hidden");
  els.selectionSummary.innerHTML = pills
    .map((text) => `<span class="summary-pill">${text}</span>`)
    .join("");
}

function showBanner(el, message, level = "info") {
  if (!message) {
    el.classList.add("hidden");
    return;
  }
  el.textContent = message;
  el.className = `status-banner ${level}`;
}

function setLoading(loading) {
  state.isLoading = loading;
  els.matchBtn.disabled = loading;
  els.matchSpinner.classList.toggle("hidden", !loading);
  els.matchBtnText.textContent = loading
    ? "Play ProBiz AI analiz ediyor..."
    : "✨ Play ProBiz AI ile Eşleştir";
}

function buildInputSignature() {
  return JSON.stringify({
    players: state.players,
    mood: state.mood,
    craving: state.craving,
    selected_game: state.selectedGame,
    selected_dessert: state.selectedDessert,
    note: els.extraNoteInput.value.trim().toLowerCase(),
  });
}

function renderMatchResult(response) {
  const { result, source, notice } = response;
  if (!result) return;

  const gameObj = state.games.find((g) => g.name === result.secilen_oyun) || state.games[0];
  const dessertObj =
    state.desserts.find((d) => d.name === result.tatli_eslesmesi) || state.desserts[0];

  els.resultGameImg.src = gameObj.image;
  els.resultGameImg.alt = result.secilen_oyun;
  els.resultGameName.textContent = result.secilen_oyun;
  els.resultGameComment.textContent = result.oyun_yorumu;

  els.resultDessertImg.src = dessertObj.image;
  els.resultDessertImg.alt = result.tatli_eslesmesi;
  els.resultDessertName.textContent = result.tatli_eslesmesi;
  els.resultSlogan.textContent = `“${result.masa_slogani}”`;
  els.resultAllergen.textContent = result.alerjen_uyarisi;

  els.resultSourceBadge.className = "source-badge";
  if (source === "gemini") {
    els.resultSourceBadge.textContent = "✨ Canlı Gemini 2.5 Flash";
    showBanner(els.statusBanner, notice, "success");
  } else if (source === "cache") {
    els.resultSourceBadge.textContent = "⚡ Önbellek • Kota Korundu";
    els.resultSourceBadge.classList.add("cache");
    showBanner(els.statusBanner, notice, "info");
  } else {
    els.resultSourceBadge.textContent = "📦 Çevrimdışı Yedek Öneri";
    els.resultSourceBadge.classList.add("offline");
    showBanner(els.statusBanner, notice, "warning");
  }

  els.resultPanel.classList.remove("hidden");
  state.aiMatchedGame = result.secilen_oyun;
  state.aiMatchedDessert = result.tatli_eslesmesi;
  // Eğer o tatlı gizli bir kategorideyse menüyü Tümü'ne al ki parladığı görünsün
  if (state.activeCategory !== "all") {
    state.activeCategory = "all";
    document.querySelectorAll(".cat-pill").forEach((p) => p.classList.toggle("active", p.dataset.cat === "all"));
    renderDesserts();
  } else {
    updateInstantHighlights();
  }
}

async function handleMatchRequest() {
  if (state.isLoading) return;

  const hasAnySelection = Boolean(
    state.players || state.mood || state.craving || state.selectedGame || state.selectedDessert
  );
  if (!hasAnySelection) {
    showBanner(
      els.statusBanner,
      "Lütfen eşleştirme için üstten en az bir tercih veya aşağıdan bir oyun/tatlı kartı seçin.",
      "warning"
    );
    return;
  }

  const signature = buildInputSignature();
  if (signature === state.lastSubmittedSignature && !els.resultPanel.classList.contains("hidden")) {
    showBanner(
      els.statusBanner,
      "Aynı seçimi zaten eşleştirdik! API kotanı korumak için tekrar istek gönderilmedi.",
      "info"
    );
    return;
  }

  const payload = {
    players: state.players,
    mood: state.mood,
    craving: state.craving,
    selected_game: state.selectedGame,
    selected_dessert: state.selectedDessert,
    note: els.extraNoteInput.value.trim(),
  };

  setLoading(true);
  showBanner(els.statusBanner, "Play ProBiz AI menüyü analiz ediyor, lütfen bekle...", "info");

  try {
    const response = await window.pywebview.api.match_with_ai(payload);
    if (!response.ok) {
      showBanner(els.statusBanner, response.notice || "Seçimler doğrulanamadı.", "warning");
      return;
    }
    state.lastSubmittedSignature = signature;
    renderMatchResult(response);
  } catch (err) {
    showBanner(els.statusBanner, "Bağlantı sırasında bir sorun oluştu. Lütfen tekrar deneyin.", "warning");
  } finally {
    setLoading(false);
  }
}

/* ---------------- MASA REZERVASYONU MANTIĞI ---------------- */
function updateLiveTicketPreview() {
  const team = els.resTeamInput.value.trim() || "Dijital Masa Bileti";
  const dateVal = els.resDateInput.value || getTodayISO();
  els.ticketTeam.textContent = team;
  els.ticketCode.textContent = state.latestTicketCode || "ÖNİZLEME";
  els.ticketDateTime.textContent = `${dateVal} • ${state.resTimeSlot}`;
  els.ticketGuests.textContent = `${state.resGuests} Kişi`;
  els.ticketGame.textContent = els.resGameSelect.value || "Kafede Seçilecek";
  els.ticketDessert.textContent = els.resDessertSelect.value || "Kafede Seçilecek";
}

function renderReservationsList() {
  els.resCountBadge.textContent = String(state.reservations.length);
  if (!state.reservations.length) {
    els.reservationsList.innerHTML =
      '<p class="empty-res-text">Henüz oluşturulmuş rezervasyon yok. Formdan saniyeler içinde ücretsiz masa ayırtabilirsin.</p>';
    return;
  }

  els.reservationsList.innerHTML = "";
  state.reservations.forEach((item) => {
    const row = document.createElement("div");
    row.className = "res-item";
    row.innerHTML = `
      <div>
        <div class="res-item-title">${item.code} • ${item.team_name}</div>
        <div class="res-item-meta">${item.date} ${item.time_slot} • ${item.guests} Kişi • ${item.game} &amp; ${item.dessert}</div>
      </div>
      <button type="button" class="res-cancel-btn" data-cancel="${item.code}">İptal</button>
    `;
    row.querySelector("[data-cancel]").addEventListener("click", async () => {
      if (hasPyWebView()) {
        const res = await window.pywebview.api.cancel_reservation(item.code);
        state.reservations = res.reservations || [];
        renderReservationsList();
        showBanner(els.resBanner, res.message, "info");
      }
    });
    els.reservationsList.appendChild(row);
  });
}

async function handleReservationSubmit(e) {
  e.preventDefault();
  const payload = {
    team_name: els.resTeamInput.value.trim(),
    date: els.resDateInput.value,
    time_slot: state.resTimeSlot,
    guests: state.resGuests,
    game: els.resGameSelect.value,
    dessert: els.resDessertSelect.value,
    note: els.resNoteInput.value.trim(),
  };

  if (hasPyWebView()) {
    const res = await window.pywebview.api.create_reservation(payload);
    if (!res.ok) {
      showBanner(els.resBanner, res.message, "warning");
      return;
    }
    state.latestTicketCode = res.reservation.code;
    state.reservations = res.reservations || [];
    updateLiveTicketPreview();
    renderReservationsList();
    showBanner(els.resBanner, res.message, "success");
  }
}

/** AI sonucunu tek tıkla rezervasyon formuna aktarır */
function transferAiMatchToReservation() {
  if (state.aiMatchedGame) els.resGameSelect.value = state.aiMatchedGame;
  if (state.aiMatchedDessert) els.resDessertSelect.value = state.aiMatchedDessert;
  if (state.players) {
    const mapped = state.players === "5+" ? "5-6" : state.players;
    state.resGuests = mapped;
    document.querySelectorAll("#resGuestRow .filter-chip").forEach((c) => {
      c.classList.toggle("selected", c.dataset.guests === mapped);
    });
  }
  state.latestTicketCode = "";
  updateLiveTicketPreview();
  document.querySelector('.nav-tab[data-tab="reservation"]').click();
  setTimeout(() => els.resTeamInput.focus(), 350);
}

function resetAllSelections() {
  state.players = "";
  state.mood = "";
  state.craving = "";
  state.selectedGame = "";
  state.selectedDessert = "";
  state.aiMatchedGame = "";
  state.aiMatchedDessert = "";
  state.lastSubmittedSignature = "";
  els.extraNoteInput.value = "";
  document.querySelectorAll("#aiSection .filter-chip.selected").forEach((c) => c.classList.remove("selected"));
  updateInstantHighlights();
  updateSelectionSummary();
  showBanner(els.statusBanner, "", "info");
}

function updateApiStatusUI() {
  if (state.hasApiKey) {
    els.apiStatusDot.className = "status-dot online";
    els.apiStatusLabel.textContent = "Gemini Hazır";
    els.currentKeyInfo.classList.remove("hidden");
    els.maskedKeyValue.textContent = state.maskedApiKey;
  } else {
    els.apiStatusDot.className = "status-dot offline";
    els.apiStatusLabel.textContent = "API Anahtarı Gir";
    els.currentKeyInfo.classList.add("hidden");
  }
}

function openApiModal() {
  els.apiModalFeedback.classList.add("hidden");
  els.apiKeyInput.value = "";
  els.apiModalOverlay.classList.remove("hidden");
  setTimeout(() => els.apiKeyInput.focus(), 60);
}

function closeApiModal() {
  els.apiModalOverlay.classList.add("hidden");
}

function setupNavTabs() {
  const sectionMap = {
    home: document.getElementById("heroSection"),
    games: document.getElementById("gamesSection"),
    menu: document.getElementById("menuSection"),
    ai: document.getElementById("aiSection"),
    reservation: document.getElementById("reservationSection"),
  };

  document.querySelectorAll(".nav-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".nav-tab").forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      const target = sectionMap[tab.dataset.tab];
      if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });

  document.getElementById("heroAiBtn").addEventListener("click", () => {
    document.querySelector('.nav-tab[data-tab="ai"]').click();
  });
  document.getElementById("heroReserveBtn").addEventListener("click", () => {
    document.querySelector('.nav-tab[data-tab="reservation"]').click();
  });
}

function bindEvents() {
  // AI filtre çipleri
  document.querySelectorAll("[data-filter-group]").forEach((row) => {
    const group = row.dataset.filterGroup;
    row.querySelectorAll(".filter-chip").forEach((chip) => {
      chip.addEventListener("click", () => {
        const val = chip.dataset.value;
        const already = state[group] === val;
        row.querySelectorAll(".filter-chip").forEach((c) => c.classList.remove("selected"));
        state[group] = already ? "" : val;
        if (!already) chip.classList.add("selected");
        state.aiMatchedGame = "";
        state.aiMatchedDessert = "";
        updateInstantHighlights();
        updateSelectionSummary();
      });
    });
  });

  // 12 Tatlı kategori barı
  document.querySelectorAll("#menuCategoryBar .cat-pill").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#menuCategoryBar .cat-pill").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.activeCategory = btn.dataset.cat;
      renderDesserts();
    });
  });

  // Rezervasyon saat ve kişi çipleri
  document.querySelectorAll("#resSlotRow .filter-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      document.querySelectorAll("#resSlotRow .filter-chip").forEach((c) => c.classList.remove("selected"));
      chip.classList.add("selected");
      state.resTimeSlot = chip.dataset.slot;
      state.latestTicketCode = "";
      updateLiveTicketPreview();
    });
  });

  document.querySelectorAll("#resGuestRow .filter-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      document.querySelectorAll("#resGuestRow .filter-chip").forEach((c) => c.classList.remove("selected"));
      chip.classList.add("selected");
      state.resGuests = chip.dataset.guests;
      state.latestTicketCode = "";
      updateLiveTicketPreview();
    });
  });

  [els.resTeamInput, els.resDateInput, els.resGameSelect, els.resDessertSelect].forEach((input) => {
    input.addEventListener("input", () => {
      state.latestTicketCode = "";
      updateLiveTicketPreview();
    });
    input.addEventListener("change", () => {
      state.latestTicketCode = "";
      updateLiveTicketPreview();
    });
  });

  els.reservationForm.addEventListener("submit", handleReservationSubmit);
  els.matchBtn.addEventListener("click", handleMatchRequest);
  els.resetSelectionsBtn.addEventListener("click", resetAllSelections);
  els.reserveFromAiBtn.addEventListener("click", transferAiMatchToReservation);

  document.getElementById("clearGameCardBtn").addEventListener("click", () => {
    state.selectedGame = "";
    state.aiMatchedGame = "";
    updateInstantHighlights();
    updateSelectionSummary();
  });

  els.openApiModalBtn.addEventListener("click", openApiModal);
  els.closeApiModalBtn.addEventListener("click", closeApiModal);
  els.continueOfflineBtn.addEventListener("click", () => {
    closeApiModal();
    showBanner(
      els.statusBanner,
      "Çevrimdışı demo modundasın. İstediğin zaman sağ üstten Gemini API anahtarını ekleyebilirsin.",
      "info"
    );
  });

  els.saveApiKeyBtn.addEventListener("click", async () => {
    const key = els.apiKeyInput.value.trim();
    if (!key) {
      els.apiModalFeedback.textContent = "Lütfen geçerli bir Gemini API anahtarı girin.";
      els.apiModalFeedback.classList.remove("hidden");
      return;
    }
    if (hasPyWebView()) {
      const res = await window.pywebview.api.save_api_key(key);
      if (!res.ok) {
        els.apiModalFeedback.textContent = res.message;
        els.apiModalFeedback.classList.remove("hidden");
        return;
      }
      state.hasApiKey = res.has_api_key;
      state.maskedApiKey = res.masked_api_key;
      state.lastSubmittedSignature = "";
      updateApiStatusUI();
      closeApiModal();
      showBanner(els.statusBanner, res.message, "success");
    }
  });

  els.clearApiKeyBtn.addEventListener("click", async () => {
    if (hasPyWebView()) {
      const res = await window.pywebview.api.clear_api_key();
      state.hasApiKey = false;
      state.maskedApiKey = "";
      state.lastSubmittedSignature = "";
      updateApiStatusUI();
      showBanner(els.statusBanner, res.message, "info");
    }
  });

  els.extraNoteInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") handleMatchRequest();
  });
}

async function initApp() {
  els.resDateInput.value = getTodayISO();
  els.resDateInput.min = getTodayISO();
  setupNavTabs();
  bindEvents();

  if (hasPyWebView()) {
    const initial = await window.pywebview.api.get_initial_state();
    state.games = initial.games || [];
    state.desserts = initial.desserts || [];
    state.reservations = initial.reservations || [];
    state.hasApiKey = Boolean(initial.has_api_key);
    state.maskedApiKey = initial.masked_api_key || "";
    if (initial.config_path) els.configPathHint.textContent = initial.config_path;

    renderGames();
    renderDesserts();
    populateReservationSelects();
    updateLiveTicketPreview();
    renderReservationsList();
    updateApiStatusUI();

    if (!state.hasApiKey) {
      openApiModal();
    }
  }
}

window.addEventListener("pywebviewready", initApp);
