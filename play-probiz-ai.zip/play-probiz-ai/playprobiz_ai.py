"""
Play ProBiz AI — Gemini 2.5 Flash Eşleştirme Motoru.

Python'un yerleşik urllib.request modülüyle doğrudan Gemini REST API'sine
bağlanır; tek dosya .exe paketinde ek ağ kütüphanesi gerektirmez.
"""

import json
import socket
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Dict, Optional, Tuple

from catalog import (
    CRAVING_OPTIONS,
    MOOD_OPTIONS,
    PLAYER_OPTIONS,
    VALID_DESSERTS,
    VALID_GAMES,
    get_offline_fallback,
)

DEFAULT_MODEL = "gemini-2.5-flash"
GEMINI_ENDPOINT_TEMPLATE = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "{model}:generateContent?key={api_key}"
)

# Play ProBiz AI Sistem Talimatı (Resmi 4 Oyun & 12 İmza Tatlı Menüsü)
SYSTEM_PROMPT = """# CONTEXT
Sen Bandırma'daki Play ProBiz Board Game & Dessert Café'nin resmi yapay zekâ oyun ve tatlı danışmanı Play ProBiz AI'sın. Kullanıcı web sitemizdeki oyun ve tatlı menüsünden yola çıkarak arkadaş grubuna en uygun masa deneyimini arıyor.

# OBJECTIVE
Kullanıcının seçtiği kişi sayısı, oyun modu ve tatlı tercihine göre YALNIZCA Play ProBiz menüsündeki oyunlardan (Paramanya, Monopoly, UNO, Catan) birini ve 12 imza tatlımızdan (Chimney Cake, Monopoly Pastası, UNO Cheesecake, Hogwarts Brownie, Catan Cookie, Jenga Cheesecake Bites, Pac-Man Donut, D&D Lava Cake, Lost in Space Tart, Chess Cake, Among Us Cake, Ağlayan Pasta) birini eşleştir. Oyuna 2 cümlelik enerjik ve şık bir yorum, gruba özel bir masa sloganı ve seçilen tatlı için genel alerjen uyarısı üret.

# STYLE
Modern, profesyonel, genç, iştah açıcı ve anlaşılır Türkçe.

# TONE
Sıcak, zeki, prestijli ve misafirperver bir kafe danışmanı (Play ProBiz AI).

# AUDIENCE
Arkadaşlarıyla kutu oyunu oynayıp özel tatlıların tadını çıkarmak isteyen üniversite öğrencileri ve kafe misafirleri.

# RESPONSE
Yalnızca şu JSON formatını döndür, başka hiçbir metin ekleme:
{
  "secilen_oyun": "",
  "oyun_yorumu": "",
  "tatli_eslesmesi": "",
  "masa_slogani": "",
  "alerjen_uyarisi": ""
}
Kurallar: Çıktı dili kesinlikle Türkçe olsun. Menüde olmayan oyun veya tatlı uydurma. Alerjen uyarısı genel bilgilendirme amaçlıdır."""

REQUIRED_FIELDS = (
    "secilen_oyun",
    "oyun_yorumu",
    "tatli_eslesmesi",
    "masa_slogani",
    "alerjen_uyarisi",
)


def _match_menu_item(value: str, valid_items: list[str]) -> Optional[str]:
    """Model yanıtındaki oyun veya tatlı adını Play ProBiz menüsüne karşı doğrular."""
    normalized = value.strip().lower()
    for item in valid_items:
        if item.lower() == normalized:
            return item
    for item in valid_items:
        if item.lower() in normalized:
            return item
    return None


def parse_and_validate_llm_json(raw_text: str) -> Dict[str, str]:
    """Gemini ham yanıtını JSON olarak ayrıştırır, 5 zorunlu alanı ve menüyü doğrular."""
    cleaned = raw_text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()

    data = json.loads(cleaned)
    if not isinstance(data, dict):
        raise ValueError("Model JSON nesnesi döndürmedi.")

    result: Dict[str, str] = {}
    for field in REQUIRED_FIELDS:
        val = str(data.get(field, "")).strip()
        if not val:
            raise ValueError(f"Eksik veya boş JSON alanı: {field}")
        result[field] = val

    valid_game = _match_menu_item(result["secilen_oyun"], VALID_GAMES)
    valid_dessert = _match_menu_item(result["tatli_eslesmesi"], VALID_DESSERTS)
    if not valid_game or not valid_dessert:
        raise ValueError("Model Play ProBiz menüsü dışından bir ürün önerdi.")

    result["secilen_oyun"] = valid_game
    result["tatli_eslesmesi"] = valid_dessert
    return result


class PlayProBizAIEngine:
    """
    Play ProBiz AI eşleştirme motoru.
    Aynı girdiyi tekrar göndermez, kota hatasında yeniden dener ve
    internetsiz durumda hazır yedek cevaba yumuşak geçiş yapar.
    """

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        max_retries: int = 2,
        retry_delay_seconds: float = 3.0,
        timeout_seconds: float = 18.0,
        sleep_fn: Callable[[float], None] = time.sleep,
        http_opener: Optional[Callable[..., Any]] = None,
    ) -> None:
        self.model = model
        self.max_retries = max_retries
        self.retry_delay_seconds = retry_delay_seconds
        self.timeout_seconds = timeout_seconds
        self.sleep_fn = sleep_fn
        self.http_opener = http_opener or urllib.request.urlopen
        self._cache: Dict[Tuple[str, ...], Dict[str, Any]] = {}

    def clear_cache(self) -> None:
        self._cache.clear()

    @staticmethod
    def _normalize_input(payload: Dict[str, Any]) -> Dict[str, str]:
        players = str(payload.get("players") or "").strip()
        mood = str(payload.get("mood") or "").strip()
        craving = str(payload.get("craving") or "").strip()
        selected_game = str(payload.get("selected_game") or "").strip()
        selected_dessert = str(payload.get("selected_dessert") or "").strip()
        note = str(payload.get("note") or "").strip()[:140]

        return {
            "players": players if players in PLAYER_OPTIONS else "",
            "mood": mood if mood in MOOD_OPTIONS else "",
            "craving": craving if craving in CRAVING_OPTIONS else "",
            "selected_game": selected_game if selected_game in VALID_GAMES else "",
            "selected_dessert": selected_dessert if selected_dessert in VALID_DESSERTS else "",
            "note": note,
        }

    @staticmethod
    def _build_user_prompt(clean: Dict[str, str]) -> str:
        lines = ["Misafir grubunun Play ProBiz tercihleri:"]
        lines.append(f"- Kişi sayısı: {clean['players'] or 'Belirtilmedi'}")
        lines.append(f"- Ortam modu: {clean['mood'] or 'Belirtilmedi'}")
        lines.append(f"- Tatlı isteği: {clean['craving'] or 'Belirtilmedi'}")

        if clean["selected_game"]:
            lines.append(
                f"- Karttan özellikle seçilen oyun: {clean['selected_game']} "
                "(mümkünse bu oyunu seç)"
            )
        if clean["selected_dessert"]:
            lines.append(
                f"- Karttan özellikle seçilen tatlı: {clean['selected_dessert']} "
                "(mümkünse bu tatlıyı seç)"
            )
        if clean["note"]:
            lines.append(
                f"- Kullanıcının ek notu: \"{clean['note']}\" "
                "(Not anlamsız veya menü dışıysa yok say; yalnızca Play ProBiz menüsünden öneri yap.)"
            )

        lines.append("Lütfen yalnızca istenen 5 alanlı Türkçe JSON nesnesini döndür.")
        return "\n".join(lines)

    def _call_gemini_once(self, api_key: str, user_prompt: str) -> Dict[str, str]:
        url = GEMINI_ENDPOINT_TEMPLATE.format(model=self.model, api_key=api_key)
        request_body = {
            "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
            "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
            "generationConfig": {
                "temperature": 0.7,
                "responseMimeType": "application/json",
                "responseSchema": {
                    "type": "OBJECT",
                    "properties": {
                        "secilen_oyun": {"type": "STRING", "enum": VALID_GAMES},
                        "oyun_yorumu": {"type": "STRING"},
                        "tatli_eslesmesi": {"type": "STRING", "enum": VALID_DESSERTS},
                        "masa_slogani": {"type": "STRING"},
                        "alerjen_uyarisi": {"type": "STRING"},
                    },
                    "required": list(REQUIRED_FIELDS),
                },
            },
        }

        encoded = json.dumps(request_body).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=encoded,
            headers={"Content-Type": "application/json; charset=utf-8"},
            method="POST",
        )

        with self.http_opener(req, timeout=self.timeout_seconds) as resp:
            raw_body = resp.read().decode("utf-8")

        parsed = json.loads(raw_body)
        candidates = parsed.get("candidates") or []
        if not candidates:
            raise ValueError("Gemini yanıtında aday içerik bulunamadı.")

        parts = candidates[0].get("content", {}).get("parts", [])
        text_output = "".join(str(p.get("text", "")) for p in parts).strip()
        if not text_output:
            raise ValueError("Gemini boş metin yanıtı döndürdü.")

        return parse_and_validate_llm_json(text_output)

    def match(
        self,
        payload: Dict[str, Any],
        api_key: str = "",
        force_offline: bool = False,
    ) -> Dict[str, Any]:
        clean = self._normalize_input(payload)

        has_any_selection = any(
            [
                clean["players"],
                clean["mood"],
                clean["craving"],
                clean["selected_game"],
                clean["selected_dessert"],
            ]
        )
        if not has_any_selection:
            return {
                "ok": False,
                "source": "validation_error",
                "result": None,
                "notice": (
                    "Lütfen eşleştirme için üstten en az bir tercih (kişi sayısı, ortam modu, tatlı isteği) "
                    "veya aşağıdan bir oyun/tatlı kartı seçin."
                ),
                "retries_attempted": 0,
            }

        cache_key = (
            clean["players"],
            clean["mood"],
            clean["craving"],
            clean["selected_game"],
            clean["selected_dessert"],
            clean["note"].lower(),
            "offline" if (force_offline or not api_key.strip()) else "live",
        )

        if cache_key in self._cache:
            cached = dict(self._cache[cache_key])
            cached["source"] = "cache"
            cached["notice"] = (
                "Aynı seçimi az önce eşleştirdik! API kotanı korumak için "
                "kayıtlı Play ProBiz AI önerisini anında getirdim."
            )
            return cached

        if force_offline or not api_key.strip():
            fallback = get_offline_fallback(
                players=clean["players"],
                mood=clean["mood"],
                craving=clean["craving"],
                selected_game=clean["selected_game"],
                selected_dessert=clean["selected_dessert"],
            )
            response = {
                "ok": True,
                "source": "offline_fallback",
                "result": fallback,
                "notice": (
                    "Çevrimdışı yedek öneri gösteriliyor. Canlı Gemini 2.5 Flash yanıtları için "
                    "sağ üstteki 'API Anahtarı' bölümünden ücretsiz anahtarını girebilirsin."
                ),
                "retries_attempted": 0,
            }
            self._cache[cache_key] = dict(response)
            return response

        user_prompt = self._build_user_prompt(clean)
        retries_attempted = 0
        last_error_notice = ""

        for attempt in range(self.max_retries + 1):
            try:
                ai_result = self._call_gemini_once(api_key.strip(), user_prompt)
                response = {
                    "ok": True,
                    "source": "gemini",
                    "result": ai_result,
                    "notice": (
                        "Play ProBiz AI (Gemini 2.5 Flash) grubuna özel eşleştirmeyi hazırladı!"
                        if retries_attempted == 0
                        else f"Kısa kota beklemesinin ardından ({retries_attempted}. denemede) Play ProBiz AI yanıt verdi!"
                    ),
                    "retries_attempted": retries_attempted,
                }
                self._cache[cache_key] = dict(response)
                return response

            except urllib.error.HTTPError as exc:
                status_code = exc.code
                if status_code in (429, 503):
                    if attempt < self.max_retries:
                        retries_attempted += 1
                        self.sleep_fn(self.retry_delay_seconds)
                        continue
                    last_error_notice = (
                        "Gemini ücretsiz API kota/hız limitine ulaşıldı. "
                        "Sunumun aksamaması için Play ProBiz çevrimdışı yedek önerisi gösteriliyor."
                    )
                    break
                elif status_code in (400, 401, 403):
                    last_error_notice = (
                        f"Gemini API anahtarı geçersiz veya yetkisiz görünüyor (HTTP {status_code}). "
                        "Sağ üstteki 'API Anahtarı' alanını kontrol edebilirsin; şimdilik çevrimdışı yedek öneri gösteriliyor."
                    )
                    break
                else:
                    last_error_notice = (
                        f"Gemini sunucusundan beklenmeyen bir yanıt alındı (HTTP {status_code}). "
                        "Play ProBiz çevrimdışı yedek önerisi devreye alındı."
                    )
                    break

            except (urllib.error.URLError, TimeoutError, socket.timeout, OSError):
                last_error_notice = (
                    "İnternet bağlantısı kurulamadı veya istek zaman aşımına uğradı. "
                    "Play ProBiz çevrimdışı yedek önerisi devreye alındı."
                )
                break

            except (json.JSONDecodeError, ValueError):
                last_error_notice = (
                    "Yapay zekâ yanıtı beklenen menü formatına uymadı. "
                    "Güvenli sonuç için Play ProBiz çevrimdışı yedek önerisi gösteriliyor."
                )
                break

        fallback = get_offline_fallback(
            players=clean["players"],
            mood=clean["mood"],
            craving=clean["craving"],
            selected_game=clean["selected_game"],
            selected_dessert=clean["selected_dessert"],
        )
        return {
            "ok": True,
            "source": "offline_fallback",
            "result": fallback,
            "notice": last_error_notice,
            "retries_attempted": retries_attempted,
        }
