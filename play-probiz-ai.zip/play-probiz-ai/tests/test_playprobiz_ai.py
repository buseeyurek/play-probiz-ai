"""
Play ProBiz AI & Masa Rezervasyonu Kapsamlı Test Paketi

Test edilen senaryolar:
1. 6 farklı geçerli kullanıcı girdisi (4 oyun ve 12 imza tatlı menüsü)
2. Boş / eksik girdi doğrulaması (API'ye gitmeden Türkçe uyarı)
3. Saçma / menü dışı not girdisi (güvenli menü sınırı koruması)
4. Aynı girdinin tekrar gönderilmemesi (önbellek / kota koruması)
5. HTTP 429 kota hatasında birkaç saniye sonra otomatik yeniden deneme & kota tükenmesi
6. İnternetsiz ortamda hazır Play ProBiz JSON yedek cevabı
7. Yerel API anahtarı saklama ve .gitignore güvenlik denetimi
8. Masa Rezervasyonu oluşturma, doğrulama, dijital bilet kodu ve iptal akışı
"""

import io
import json
import urllib.error
from pathlib import Path
from typing import Dict

import pytest

from catalog import DESSERTS_CATALOG, GAMES_CATALOG, VALID_DESSERTS, VALID_GAMES
from config_manager import clear_api_key, load_api_key, mask_api_key, save_api_key
from playprobiz_ai import (
    PlayProBizAIEngine,
    REQUIRED_FIELDS,
    SYSTEM_PROMPT,
    parse_and_validate_llm_json,
)
from reservation_manager import ReservationManager


class FakeHTTPResponse:
    def __init__(self, payload: Dict) -> None:
        self._raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")

    def read(self) -> bytes:
        return self._raw

    def __enter__(self) -> "FakeHTTPResponse":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


def _wrap_gemini_json(result_dict: Dict[str, str]) -> FakeHTTPResponse:
    return FakeHTTPResponse(
        {
            "candidates": [
                {
                    "content": {
                        "parts": [{"text": json.dumps(result_dict, ensure_ascii=False)}]
                    }
                }
            ]
        }
    )


def _assert_valid_result(result: Dict[str, str]) -> None:
    for field in REQUIRED_FIELDS:
        assert field in result and isinstance(result[field], str) and result[field].strip()
    assert result["secilen_oyun"] in VALID_GAMES
    assert result["tatli_eslesmesi"] in VALID_DESSERTS


def test_catalog_has_4_games_and_12_signature_desserts():
    assert len(GAMES_CATALOG) == 4
    assert len(DESSERTS_CATALOG) == 12
    assert len(VALID_DESSERTS) == 12
    assert "Monopoly Pastası" in VALID_DESSERTS
    assert "Hogwarts Brownie" in VALID_DESSERTS
    assert "D&D Lava Cake" in VALID_DESSERTS
    assert "Ağlayan Pasta" in VALID_DESSERTS
    # Eski maskot adının sistem talimatında geçmediğini doğrula
    assert "çipiti" not in SYSTEM_PROMPT.lower()
    assert "Play ProBiz AI" in SYSTEM_PROMPT


@pytest.mark.parametrize(
    "payload,mock_game,mock_dessert",
    [
        ({"players": "2", "mood": "Rekabetçi", "craving": "Çikolatalı"}, "Paramanya", "Hogwarts Brownie"),
        ({"players": "3-4", "mood": "Strateji", "craving": "Klasik"}, "Catan", "Catan Cookie"),
        ({"players": "5+", "mood": "Kahkahalı", "craving": "Meyveli"}, "UNO", "UNO Cheesecake"),
        ({"players": "2", "mood": "Hızlı", "craving": "Sürpriz"}, "UNO", "Pac-Man Donut"),
        ({"selected_game": "Monopoly", "selected_dessert": "Monopoly Pastası"}, "Monopoly", "Monopoly Pastası"),
        ({"selected_game": "Catan", "selected_dessert": "Chess Cake"}, "Catan", "Chess Cake"),
    ],
)
def test_six_different_valid_inputs(payload, mock_game, mock_dessert):
    captured = []

    def fake_urlopen(req, timeout=15):
        captured.append(json.loads(req.data.decode("utf-8")))
        return _wrap_gemini_json(
            {
                "secilen_oyun": mock_game,
                "oyun_yorumu": f"{mock_game} ile masada heyecan tavan yapacak! Arkadaşlarınla unutulmaz bir tur seni bekliyor.",
                "tatli_eslesmesi": mock_dessert,
                "masa_slogani": f"{mock_game} + {mock_dessert} ile Play ProBiz masası hazır!",
                "alerjen_uyarisi": "Genel bilgilendirme: Gluten, süt ürünleri ve yumurta içerebilir.",
            }
        )

    engine = PlayProBizAIEngine(http_opener=fake_urlopen, sleep_fn=lambda _: None)
    resp = engine.match(payload, api_key="TEST_FAKE_KEY_123456")

    assert resp["ok"] is True
    assert resp["source"] == "gemini"
    _assert_valid_result(resp["result"])
    assert resp["result"]["secilen_oyun"] == mock_game
    assert resp["result"]["tatli_eslesmesi"] == mock_dessert
    assert captured[0]["system_instruction"]["parts"][0]["text"] == SYSTEM_PROMPT


@pytest.mark.parametrize(
    "empty_payload",
    [
        {},
        {"players": "", "mood": "", "craving": ""},
        {"note": "sadece not yazdım ama seçim yapmadım"},
        {"players": "99", "mood": "Bilinmeyen", "selected_game": "Satranç"},
    ],
)
def test_empty_or_invalid_selection_blocks_api_call(empty_payload):
    called = False

    def fail_if_called(req, timeout=15):
        nonlocal called
        called = True
        raise AssertionError("Boş seçimde API çağrılmamalıydı!")

    engine = PlayProBizAIEngine(http_opener=fail_if_called)
    resp = engine.match(empty_payload, api_key="TEST_FAKE_KEY_123456")

    assert resp["ok"] is False
    assert resp["source"] == "validation_error"
    assert called is False


def test_nonsense_note_stays_within_menu():
    def fake_hallucinated(req, timeout=15):
        return _wrap_gemini_json(
            {
                "secilen_oyun": "Tavla",
                "oyun_yorumu": "Uydurma",
                "tatli_eslesmesi": "Baklava",
                "masa_slogani": "Uydurma",
                "alerjen_uyarisi": "Fıstık",
            }
        )

    engine = PlayProBizAIEngine(http_opener=fake_hallucinated)
    resp = engine.match(
        {"players": "2", "mood": "Hızlı", "note": "asdfg 999 uzay gemisi baklava"},
        api_key="TEST_FAKE_KEY_123456",
    )
    assert resp["ok"] is True
    assert resp["source"] == "offline_fallback"
    _assert_valid_result(resp["result"])


def test_duplicate_input_uses_cache():
    calls = 0

    def fake_urlopen(req, timeout=15):
        nonlocal calls
        calls += 1
        return _wrap_gemini_json(
            {
                "secilen_oyun": "Paramanya",
                "oyun_yorumu": "Dünya şehirlerini toplayıp şans kartlarıyla rakipleri şaşırtın! Rekabet dolu bir masa sizi bekliyor.",
                "tatli_eslesmesi": "Lost in Space Tart",
                "masa_slogani": "Dünyayı fethet, galaksinin en tatlı tartıyla kutla!",
                "alerjen_uyarisi": "Genel bilgilendirme: Gluten, süt ve yumurta içerebilir.",
            }
        )

    engine = PlayProBizAIEngine(http_opener=fake_urlopen)
    payload = {"players": "3-4", "mood": "Rekabetçi", "craving": "Meyveli"}
    first = engine.match(payload, api_key="TEST_FAKE_KEY_123456")
    second = engine.match(payload, api_key="TEST_FAKE_KEY_123456")

    assert first["source"] == "gemini"
    assert second["source"] == "cache"
    assert calls == 1


def test_quota_limit_retries_and_succeeds():
    attempts = 0
    slept = []

    def flaky(req, timeout=15):
        nonlocal attempts
        attempts += 1
        if attempts == 1:
            raise urllib.error.HTTPError(
                req.full_url, 429, "Too Many Requests", {}, io.BytesIO(b"quota")
            )
        return _wrap_gemini_json(
            {
                "secilen_oyun": "Catan",
                "oyun_yorumu": "Strateji ve ticaretin en keyifli hali! Akıllı takaslarla adanın lideri olacaksınız.",
                "tatli_eslesmesi": "D&D Lava Cake",
                "masa_slogani": "Critical hit strateji, sıcak D&D Lava Cake!",
                "alerjen_uyarisi": "Genel bilgilendirme: Gluten, süt, yumurta ve bitter çikolata içerebilir.",
            }
        )

    engine = PlayProBizAIEngine(
        max_retries=2,
        retry_delay_seconds=2.0,
        sleep_fn=lambda s: slept.append(s),
        http_opener=flaky,
    )
    resp = engine.match(
        {"players": "3-4", "mood": "Strateji", "craving": "Çikolatalı"},
        api_key="TEST_FAKE_KEY_123456",
    )
    assert resp["ok"] is True
    assert resp["source"] == "gemini"
    assert resp["retries_attempted"] == 1
    assert slept == [2.0]


def test_offline_network_failure_returns_fallback():
    def offline(req, timeout=15):
        raise urllib.error.URLError("İnternet yok")

    engine = PlayProBizAIEngine(http_opener=offline)
    resp = engine.match(
        {"players": "5+", "mood": "Kahkahalı", "craving": "Sürpriz"},
        api_key="TEST_FAKE_KEY_123456",
    )
    assert resp["ok"] is True
    assert resp["source"] == "offline_fallback"
    assert "İnternet" in resp["notice"]
    _assert_valid_result(resp["result"])


def test_local_api_key_and_gitignore(tmp_path: Path):
    cfg = tmp_path / "local_config.json"
    save_api_key("AIzaSyFakeDemoKey987654321", cfg)
    assert load_api_key(cfg) == "AIzaSyFakeDemoKey987654321"
    assert mask_api_key("AIzaSyFakeDemoKey987654321") == "AIza••••••4321"
    clear_api_key(cfg)
    assert not cfg.exists()

    gi = (Path(__file__).resolve().parent.parent / ".gitignore").read_text(encoding="utf-8")
    assert "local_config.json" in gi
    assert "local_reservations.json" in gi


def test_reservation_lifecycle(tmp_path: Path):
    mgr = ReservationManager(storage_path=tmp_path / "reservations.json")
    assert mgr.list_reservations() == []

    # Eksik takım adı reddedilmeli
    bad = mgr.create_reservation({"team_name": "", "date": "2026-11-22", "time_slot": "18:00", "guests": "3-4"})
    assert bad["ok"] is False

    # Geçerli rezervasyon dijital bilet oluşturmalı
    created = mgr.create_reservation(
        {
            "team_name": "Bandırma Stratejistleri",
            "date": "2026-11-22",
            "time_slot": "20:00",
            "guests": "3-4",
            "game": "Catan",
            "dessert": "Catan Cookie",
            "note": "Köşe masa",
        }
    )
    assert created["ok"] is True
    code = created["reservation"]["code"]
    assert code.startswith("PBZ-")
    assert created["reservation"]["table_fee"] == "₺0 (Masa Ücreti Yok)"
    assert len(mgr.list_reservations()) == 1

    # İptal akışı
    canceled = mgr.cancel_reservation(code)
    assert canceled["ok"] is True
    assert mgr.list_reservations() == []
