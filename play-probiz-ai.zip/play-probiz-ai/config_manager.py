"""
Yerel ayar, rezervasyon ve kaynak yolu yöneticisi.

API anahtarı asla kaynak koduna veya .exe içine gömülmez; kullanıcının
bilgisayarında yerel bir JSON ayar dosyasında saklanır.
"""

import json
import os
import sys
from pathlib import Path
from typing import Optional


def get_base_dir() -> Path:
    """PyInstaller --onefile geçici klasörünü veya proje kökünü döndürür."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


def get_resource_path(relative_path: str) -> Path:
    """Paket içi HTML, CSS, JS ve görsel dosyalarının tam yolunu çözer."""
    return get_base_dir() / relative_path


def _get_user_data_dir() -> Path:
    """Paketli .exe çalışırken kullanıcı verilerinin yazılacağı yerel klasör."""
    if os.name == "nt":
        app_data = os.environ.get("APPDATA") or str(Path.home())
        data_dir = Path(app_data) / "PlayProBiz"
    else:
        data_dir = Path.home() / ".config" / "PlayProBiz"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir


def get_config_path() -> Path:
    """API anahtarının saklanacağı yerel ayar dosyası yolu."""
    if getattr(sys, "frozen", False):
        return _get_user_data_dir() / "config.json"
    return Path(__file__).resolve().parent / "local_config.json"


def get_reservations_path() -> Path:
    """Masa rezervasyonlarının saklanacağı yerel dosya yolu."""
    if getattr(sys, "frozen", False):
        return _get_user_data_dir() / "reservations.json"
    return Path(__file__).resolve().parent / "local_reservations.json"


def load_api_key(config_path: Optional[Path] = None) -> str:
    """Kayıtlı Gemini API anahtarını yerel ayar dosyasından veya ortam değişkeninden okur."""
    path = config_path or get_config_path()
    if path.exists():
        try:
            with path.open("r", encoding="utf-8") as fh:
                data = json.load(fh)
            key = str(data.get("gemini_api_key", "")).strip()
            if key:
                return key
        except (OSError, json.JSONDecodeError):
            pass

    return os.environ.get("GEMINI_API_KEY", "").strip()


def save_api_key(api_key: str, config_path: Optional[Path] = None) -> Path:
    """Kullanıcının girdiği Gemini API anahtarını yerel ayar dosyasına kaydeder."""
    cleaned = api_key.strip()
    if not cleaned:
        raise ValueError("API anahtarı boş bırakılamaz.")

    path = config_path or get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8") as fh:
        json.dump({"gemini_api_key": cleaned}, fh, ensure_ascii=False, indent=2)

    if os.name != "nt":
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass

    return path


def clear_api_key(config_path: Optional[Path] = None) -> None:
    """Yerel ayar dosyasındaki API anahtarını temizler."""
    path = config_path or get_config_path()
    if path.exists():
        try:
            path.unlink()
        except OSError:
            pass


def mask_api_key(api_key: str) -> str:
    """API anahtarını arayüzde güvenle göstermek için ortasını gizler."""
    cleaned = api_key.strip()
    if not cleaned:
        return ""
    if len(cleaned) <= 8:
        return "*" * len(cleaned)
    return f"{cleaned[:4]}••••••{cleaned[-4:]}"
