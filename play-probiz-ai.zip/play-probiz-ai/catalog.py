"""
Play ProBiz resmi oyun (4) ve imza tatlı (12) menü kataloğu.

Bandırma Play ProBiz Board Game & Dessert Café'nin gerçek menüsünü,
anlık filtre eşleştirme kurallarını ve çevrimdışı yedek önerilerini içerir.
"""

from typing import Dict, List, Optional, Tuple

# Resmi Play ProBiz oyun listesi
VALID_GAMES: List[str] = ["Paramanya", "Monopoly", "UNO", "Catan"]

# Resmi Play ProBiz 12 imza tatlı listesi
VALID_DESSERTS: List[str] = [
    "Chimney Cake",
    "Monopoly Pastası",
    "UNO Cheesecake",
    "Hogwarts Brownie",
    "Catan Cookie",
    "Jenga Cheesecake Bites",
    "Pac-Man Donut",
    "D&D Lava Cake",
    "Lost in Space Tart",
    "Chess Cake",
    "Among Us Cake",
    "Ağlayan Pasta",
]

# Filtre seçenekleri
PLAYER_OPTIONS: List[str] = ["2", "3-4", "5+"]
MOOD_OPTIONS: List[str] = ["Kahkahalı", "Rekabetçi", "Strateji", "Hızlı"]
CRAVING_OPTIONS: List[str] = ["Çikolatalı", "Meyveli", "Klasik", "Sürpriz"]
RESERVATION_SLOTS: List[str] = ["14:00", "16:00", "18:00", "20:00", "22:00"]

# Oyun kartı detayları
GAMES_CATALOG: List[Dict] = [
    {
        "id": "paramanya",
        "name": "Paramanya",
        "tagline": "Kendi imparatorluğunu kur, dünyayı yönet!",
        "description": "Dünya şehirlerini topla, simge yapılar dik ve şans kartlarıyla masanın kaderini değiştir.",
        "image": "assets/game_paramanya.jpg",
        "featured": True,
        "players": ["2", "3-4"],
        "moods": ["Rekabetçi", "Kahkahalı"],
        "duration": "35-45 dk",
        "badge": "Popüler",
    },
    {
        "id": "monopoly",
        "name": "Monopoly",
        "tagline": "Emlak krallığının zamansız klasiği!",
        "description": "Caddeleri satın al, otellerini yükselterek rakiplerini kira krizine sok.",
        "image": "assets/game_monopoly.jpg",
        "featured": False,
        "players": ["3-4", "5+"],
        "moods": ["Rekabetçi", "Strateji"],
        "duration": "60-90 dk",
        "badge": "Klasik",
    },
    {
        "id": "uno",
        "name": "UNO",
        "tagline": "+4 kartıyla dostlukları sınayan hızlı eğlence!",
        "description": "Renkleri eşleştir, yönü tersine çevir ve son kartta UNO diye bağırmayı unutma.",
        "image": "assets/game_uno.jpg",
        "featured": False,
        "players": ["2", "3-4", "5+"],
        "moods": ["Kahkahalı", "Hızlı"],
        "duration": "15-25 dk",
        "badge": "Hızlı Tur",
    },
    {
        "id": "catan",
        "name": "Catan",
        "tagline": "Kaynak topla, ticaret yap, adanın hakimi ol!",
        "description": "Buğday, odun ve tuğla takaslarıyla köylerini kur; strateji dolu unutulmaz bir masa gecesi.",
        "image": "assets/game_catan.jpg",
        "featured": False,
        "players": ["3-4"],
        "moods": ["Strateji", "Rekabetçi"],
        "duration": "60-75 dk",
        "badge": "Strateji",
    },
]

# Resmi Play ProBiz 12 İmza Tatlı Menüsü ("Her oyun, ayrı bir lezzet!")
DESSERTS_CATALOG: List[Dict] = [
    {
        "id": "chimney_cake",
        "name": "Chimney Cake",
        "note": "Dışı çıtır içi yumuşak",
        "subtitle": "Sıcak, çıtır dışı ve yumuşacık içiyle klasikleşmiş bir lezzet.",
        "image": "assets/dessert_chimney_cake.jpg",
        "cravings": ["Klasik", "Sürpriz"],
        "recommended_games": ["Paramanya", "Catan"],
        "allergen": "Genel bilgilendirme: Gluten (buğday unu), süt ürünleri, krema ve eser miktarda yumurta/kuruyemiş içerebilir.",
    },
    {
        "id": "monopoly_pastasi",
        "name": "Monopoly Pastası",
        "note": "Tüm mülkler senin olsun!",
        "subtitle": "Yalnızca kazananlar için değil, her oyuncu için özel.",
        "image": "assets/dessert_monopoly_pastasi.jpg",
        "cravings": ["Çikolatalı", "Klasik"],
        "recommended_games": ["Monopoly", "Paramanya"],
        "allergen": "Genel bilgilendirme: Gluten, süt ürünleri, yumurta, kakao/soya lesitini ve şeker hamuru içerebilir.",
    },
    {
        "id": "uno_cheesecake",
        "name": "UNO Cheesecake",
        "note": "Bir dilim daha!",
        "subtitle": "Renkli kartlar kadar eğlenceli, kremsi ve hafif.",
        "image": "assets/dessert_uno_cheesecake.jpg",
        "cravings": ["Meyveli", "Klasik"],
        "recommended_games": ["UNO"],
        "allergen": "Genel bilgilendirme: Süt ürünleri (krem peynir), gluten (bisküvi tabanı), yumurta ve gıda renklendiricisi içerebilir.",
    },
    {
        "id": "hogwarts_brownie",
        "name": "Hogwarts Brownie",
        "note": "Hogwarts'tan daha tatlı bir yer yok!",
        "subtitle": "Büyülü çikolata, yoğun brownie dokusu ve özel sos.",
        "image": "assets/dessert_hogwarts_brownie.jpg",
        "cravings": ["Çikolatalı"],
        "recommended_games": ["Monopoly", "Catan"],
        "allergen": "Genel bilgilendirme: Gluten, yumurta, süt ürünleri, bitter çikolata (soya) ve eser miktarda fındık/ceviz içerebilir.",
    },
    {
        "id": "catan_cookie",
        "name": "Catan Cookie",
        "note": "Hayat bir strateji oyunu!",
        "subtitle": "Kıtalar, kaynaklar ve bol çikolata bir arada.",
        "image": "assets/dessert_catan_cookie.jpg",
        "cravings": ["Çikolatalı", "Klasik"],
        "recommended_games": ["Catan"],
        "allergen": "Genel bilgilendirme: Gluten, tereyağı (süt), yumurta, çikolata parçacıkları ve eser miktarda kuruyemiş içerebilir.",
    },
    {
        "id": "jenga_cheesecake",
        "name": "Jenga Cheesecake Bites",
        "note": "Dikkat! Yıkılabilir lezzet!",
        "subtitle": "Kat kat mutluluk, her lokmada denge senin elinde.",
        "image": "assets/dessert_jenga_cheesecake.jpg",
        "cravings": ["Klasik", "Sürpriz"],
        "recommended_games": ["UNO", "Paramanya"],
        "allergen": "Genel bilgilendirme: Süt ürünleri (krem peynir), gluten, yumurta ve karamel/çikolata sosu içerebilir.",
    },
    {
        "id": "pacman_donut",
        "name": "Pac-Man Donut",
        "note": "Puanlar tatlıyla tamamlanır!",
        "subtitle": "Retro oyunun ruhunda, renkli ve eğlenceli.",
        "image": "assets/dessert_pacman_donut.jpg",
        "cravings": ["Meyveli", "Sürpriz"],
        "recommended_games": ["UNO", "Paramanya"],
        "allergen": "Genel bilgilendirme: Gluten, süt, yumurta, glazür ve eser miktarda soya/kuruyemiş içerebilir.",
    },
    {
        "id": "dnd_lava_cake",
        "name": "D&D Lava Cake",
        "note": "Critical hit!",
        "subtitle": "Zorlu bir macera, tatlı bir ödül.",
        "image": "assets/dessert_dnd_lava_cake.jpg",
        "cravings": ["Çikolatalı", "Sürpriz"],
        "recommended_games": ["Catan", "Monopoly"],
        "allergen": "Genel bilgilendirme: Gluten, yumurta, süt ürünleri ve yoğun bitter çikolata (soya lesitini) içerebilir.",
    },
    {
        "id": "lost_in_space_tart",
        "name": "Lost in Space Tart",
        "note": "Uzayda da tatlılar var!",
        "subtitle": "Galaksinin en tatlı yolculuğu.",
        "image": "assets/dessert_lost_in_space_tart.jpg",
        "cravings": ["Meyveli", "Sürpriz"],
        "recommended_games": ["Paramanya", "Catan"],
        "allergen": "Genel bilgilendirme: Gluten (tart hamuru), süt ürünleri, yumurta, meyve/galaksi glazürü içerebilir.",
    },
    {
        "id": "chess_cake",
        "name": "Chess Cake",
        "note": "Her hamle lezzetli!",
        "subtitle": "Strateji, sabır ve çikolatanın mükemmel dengesi.",
        "image": "assets/dessert_chess_cake.jpg",
        "cravings": ["Çikolatalı", "Klasik"],
        "recommended_games": ["Catan", "Monopoly"],
        "allergen": "Genel bilgilendirme: Gluten, süt ürünleri, yumurta, beyaz/bitter çikolata ve soya içerebilir.",
    },
    {
        "id": "among_us_cake",
        "name": "Among Us Cake",
        "note": "Tatlı impostor olma!",
        "subtitle": "Kimin impostor olduğunu kimse bilemez...",
        "image": "assets/dessert_among_us_cake.jpg",
        "cravings": ["Meyveli", "Sürpriz"],
        "recommended_games": ["UNO", "Paramanya"],
        "allergen": "Genel bilgilendirme: Gluten, süt ürünleri, yumurta, kırmızı meyveli sos ve şeker hamuru içerebilir.",
    },
    {
        "id": "aglayan_pasta",
        "name": "Ağlayan Pasta",
        "note": "Ağlamak yok, yeniden dene!",
        "subtitle": "Oyun kaybedenler için özel. Çünkü her kayıp, yeni bir oyuna başlamaktır.",
        "image": "assets/dessert_aglayan_pasta.jpg",
        "cravings": ["Çikolatalı", "Klasik"],
        "recommended_games": ["Monopoly", "UNO"],
        "allergen": "Genel bilgilendirme: Gluten, süt ürünleri (krema), yumurta ve yoğun çikolata sosu içerebilir.",
    },
]

# Çevrimdışı / kota aşımı durumunda kullanılacak hazır imza kombinasyonlar
OFFLINE_FALLBACK_COMBOS: Dict[Tuple[str, str], Dict[str, str]] = {
    ("Monopoly", "Monopoly Pastası"): {
        "secilen_oyun": "Monopoly",
        "oyun_yorumu": "Caddeleri toplayıp otelleri yükselttikçe pazarlık sesleri tüm kafeyi saracak! Rekabet dozunun zirveye çıktığı efsane bir masa gecesine hazır olun.",
        "tatli_eslesmesi": "Monopoly Pastası",
        "masa_slogani": "Tüm mülkler senin olsun, Monopoly Pastası masayı taçlandırsın!",
        "alerjen_uyarisi": "Genel bilgilendirme: Monopoly Pastası; gluten, süt ürünleri, yumurta, kakao/soya lesitini ve şeker hamuru içerebilir.",
    },
    ("UNO", "UNO Cheesecake"): {
        "secilen_oyun": "UNO",
        "oyun_yorumu": "+4 kartları havada uçuşurken bir saniye bile nefes almaya vakit kalmayacak! Hızlı, kahkahalı ve bol itirazlı turlar için masanın en enerjik kart oyunu.",
        "tatli_eslesmesi": "UNO Cheesecake",
        "masa_slogani": "Son kartı at, UNO diye bağır, bir dilim UNO Cheesecake daha kap!",
        "alerjen_uyarisi": "Genel bilgilendirme: UNO Cheesecake; süt ürünleri (krem peynir), gluten (bisküvi tabanı) ve yumurta içerebilir.",
    },
    ("Catan", "Catan Cookie"): {
        "secilen_oyun": "Catan",
        "oyun_yorumu": "Buğdayla tuğla takas ederken zekice ittifaklar kuracak, en uzun yolu kapmak için ter dökeceksiniz! Strateji sever ekiplerin Bandırma'daki vazgeçilmez masa klasiği.",
        "tatli_eslesmesi": "Catan Cookie",
        "masa_slogani": "Kaynakları topla, Catan Cookie'yi paylaş, adanın lideri ol!",
        "alerjen_uyarisi": "Genel bilgilendirme: Catan Cookie; gluten, süt ürünleri (tereyağı), yumurta, çikolata ve eser miktarda kuruyemiş içerebilir.",
    },
    ("Paramanya", "Lost in Space Tart"): {
        "secilen_oyun": "Paramanya",
        "oyun_yorumu": "Dünya şehirlerini toplarken şans zarlarıyla masadaki dengeler her tur ters yüz olacak! Hem rekabet hem kahkaha arayan ekibiniz için tam isabet bir seçim.",
        "tatli_eslesmesi": "Lost in Space Tart",
        "masa_slogani": "Dünyayı fethet, galaksinin en tatlı tartıyla zaferi kutla!",
        "alerjen_uyarisi": "Genel bilgilendirme: Lost in Space Tart; gluten (tart hamuru), süt ürünleri, yumurta ve meyve glazürü içerebilir.",
    },
    ("Paramanya", "Chimney Cake"): {
        "secilen_oyun": "Paramanya",
        "oyun_yorumu": "Dünya turunda simge yapıları arka arkaya dikerken heyecan bir an bile düşmeyecek! Tempolu turlarıyla arkadaşlarınızla uzun süre konuşulacak anlar biriktireceksiniz.",
        "tatli_eslesmesi": "Chimney Cake",
        "masa_slogani": "Zarlar dönsün, sıcak Chimney Cake kokusu masayı sarsın!",
        "alerjen_uyarisi": "Genel bilgilendirme: Chimney Cake; gluten (buğday unu), süt ürünleri ve eser miktarda yumurta/kuruyemiş içerebilir.",
    },
    ("Catan", "Chess Cake"): {
        "secilen_oyun": "Catan",
        "oyun_yorumu": "Her zar atışında kaynak dengesi değişirken sabırlı stratejinle masaya hükmedeceksin! Uzun soluklu strateji tutkunlarına özel elit bir eşleşme.",
        "tatli_eslesmesi": "Chess Cake",
        "masa_slogani": "Her hamle stratejik, her dilim Chess Cake efsane!",
        "alerjen_uyarisi": "Genel bilgilendirme: Chess Cake; gluten, süt ürünleri, yumurta ve bitter/beyaz çikolata içerebilir.",
    },
    ("UNO", "Among Us Cake"): {
        "secilen_oyun": "UNO",
        "oyun_yorumu": "Yön değiştirme ve +4 sürprizleriyle masada kimsenin kimseye güveni kalmayacak! Bol kahkahalı ve yüksek tempolu arkadaş buluşmalarının yıldızı.",
        "tatli_eslesmesi": "Among Us Cake",
        "masa_slogani": "Kartları sakla, tatlı impostor'u Among Us Cake eşliğinde yakala!",
        "alerjen_uyarisi": "Genel bilgilendirme: Among Us Cake; gluten, süt ürünleri, yumurta ve meyveli sos/şeker hamuru içerebilir.",
    },
}


def pick_best_local_pair(
    players: Optional[str] = None,
    mood: Optional[str] = None,
    craving: Optional[str] = None,
    selected_game: Optional[str] = None,
    selected_dessert: Optional[str] = None,
) -> Tuple[str, str]:
    """Kullanıcının tercihlerine en uygun (oyun, tatlı) çiftini çevrimdışı belirler."""
    if selected_game in VALID_GAMES:
        best_game = selected_game
    else:
        best_game = "Paramanya"
        best_score = -1
        for game in GAMES_CATALOG:
            score = 0
            if players and players in game["players"]:
                score += 2
            if mood and mood in game["moods"]:
                score += 3
            if score > best_score:
                best_score = score
                best_game = game["name"]

    if selected_dessert in VALID_DESSERTS:
        best_dessert = selected_dessert
    else:
        best_dessert = "Chimney Cake"
        best_d_score = -1
        for dessert in DESSERTS_CATALOG:
            score = 0
            if craving and craving in dessert["cravings"]:
                score += 3
            if best_game in dessert.get("recommended_games", []):
                score += 2
            if score > best_d_score:
                best_d_score = score
                best_dessert = dessert["name"]

    return best_game, best_dessert


def get_offline_fallback(
    players: Optional[str] = None,
    mood: Optional[str] = None,
    craving: Optional[str] = None,
    selected_game: Optional[str] = None,
    selected_dessert: Optional[str] = None,
) -> Dict[str, str]:
    """Play ProBiz menüsüne %100 uyumlu hazır JSON yedek cevap döndürür."""
    game_name, dessert_name = pick_best_local_pair(
        players=players,
        mood=mood,
        craving=craving,
        selected_game=selected_game,
        selected_dessert=selected_dessert,
    )

    if (game_name, dessert_name) in OFFLINE_FALLBACK_COMBOS:
        return dict(OFFLINE_FALLBACK_COMBOS[(game_name, dessert_name)])

    game_info = next(g for g in GAMES_CATALOG if g["name"] == game_name)
    dessert_info = next(d for d in DESSERTS_CATALOG if d["name"] == dessert_name)

    return {
        "secilen_oyun": game_name,
        "oyun_yorumu": (
            f"{game_info['tagline']} {game_info['description']} "
            f"Play ProBiz masalarında arkadaşlarınızla zamanın nasıl geçtiğini anlamayacaksınız!"
        ),
        "tatli_eslesmesi": dessert_name,
        "masa_slogani": f"{game_name} heyecanı, imza {dessert_name} lezzetiyle Play ProBiz'de!",
        "alerjen_uyarisi": dessert_info["allergen"],
    }
