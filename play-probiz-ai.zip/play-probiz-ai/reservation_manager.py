"""
Play ProBiz Yerel Masa Rezervasyon Yöneticisi.

Kişisel telefon/e-posta toplamadan yalnızca takım takma adı, tarih, saat,
kişi sayısı ve seçilen oyun/tatlı ile yerel dijital masa bileti oluşturur.
"""

import json
import random
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from catalog import RESERVATION_SLOTS, VALID_DESSERTS, VALID_GAMES
from config_manager import get_reservations_path


class ReservationManager:
    """Masa rezervasyonlarını yerel JSON dosyasında saklar ve yönetir."""

    def __init__(self, storage_path: Optional[Path] = None) -> None:
        self._path = storage_path or get_reservations_path()

    def list_reservations(self) -> List[Dict[str, Any]]:
        """Kayıtlı aktif rezervasyonları en yeniden eskiye döndürür."""
        if not self._path.exists():
            return []
        try:
            with self._path.open("r", encoding="utf-8") as fh:
                data = json.load(fh)
            if isinstance(data, list):
                return data
        except (OSError, json.JSONDecodeError):
            pass
        return []

    def _save_all(self, items: List[Dict[str, Any]]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with self._path.open("w", encoding="utf-8") as fh:
            json.dump(items, fh, ensure_ascii=False, indent=2)

    def create_reservation(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Girdileri doğrular, PBZ-XXXX kodlu dijital masa bileti oluşturup kaydeder."""
        team_name = str(payload.get("team_name") or "").strip()[:50]
        date_str = str(payload.get("date") or "").strip()
        time_slot = str(payload.get("time_slot") or "").strip()
        guests = str(payload.get("guests") or "").strip()
        game = str(payload.get("game") or "").strip()
        dessert = str(payload.get("dessert") or "").strip()
        note = str(payload.get("note") or "").strip()[:120]

        if not team_name:
            return {"ok": False, "message": "Lütfen masanız için bir grup / masa takma adı yazın."}
        if not date_str:
            return {"ok": False, "message": "Lütfen rezervasyon tarihi seçin."}
        if time_slot not in RESERVATION_SLOTS:
            return {"ok": False, "message": "Lütfen geçerli bir saat dilimi seçin."}
        if guests not in ("2", "3-4", "5-6", "7+"):
            return {"ok": False, "message": "Lütfen kişi sayısını seçin."}

        if game not in VALID_GAMES:
            game = "Kafede Seçilecek"
        if dessert not in VALID_DESSERTS:
            dessert = "Kafede Seçilecek"

        items = self.list_reservations()
        existing_codes = {item.get("code") for item in items}
        code = f"PBZ-{random.randint(1000, 9999)}"
        while code in existing_codes:
            code = f"PBZ-{random.randint(1000, 9999)}"

        reservation = {
            "code": code,
            "team_name": team_name,
            "date": date_str,
            "time_slot": time_slot,
            "guests": guests,
            "game": game,
            "dessert": dessert,
            "note": note,
            "table_fee": "₺0 (Masa Ücreti Yok)",
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        }

        items.insert(0, reservation)
        self._save_all(items)
        return {
            "ok": True,
            "reservation": reservation,
            "reservations": items,
            "message": f"{code} kodlu masanız başarıyla ayrıldı! Play ProBiz Bandırma'da görüşmek üzere.",
        }

    def cancel_reservation(self, code: str) -> Dict[str, Any]:
        """Verilen rezervasyon kodunu listeden kaldırır."""
        cleaned = str(code or "").strip()
        items = self.list_reservations()
        updated = [item for item in items if item.get("code") != cleaned]
        if len(updated) == len(items):
            return {"ok": False, "message": "Rezervasyon kodu bulunamadı.", "reservations": items}

        self._save_all(updated)
        return {
            "ok": True,
            "reservations": updated,
            "message": f"{cleaned} kodlu rezervasyon iptal edildi.",
        }
