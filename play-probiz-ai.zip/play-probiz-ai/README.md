# Play ProBiz — Play ProBiz AI & Masa Rezervasyonu

**Play ProBiz**, Bandırma'da arkadaş gruplarının masa ücreti ödemeden kutu oyunları oynayıp her oyuna özel tasarlanmış 12 imza tatlının tadını çıkardığı yenilikçi bir konsept kafedir (*PLAY • TAT • TEKRAR OYNA*).

---

## Uygulama Ne Yapar?

Play ProBiz web sitesinin birebir neon mor tasarım dilini taşıyan bu Windows masaüstü uygulaması, misafirlerin oyun & tatlı seçimini kolaylaştırır ve tek tıkla ücretsiz masa rezervasyonu yapmalarını sağlar:

- **Play ProBiz Web Sitesi Görünümü:** Üstte Play ProBiz logosu ve `Ana Sayfa / Oyunlar / Tatlı Menüsü / Play ProBiz AI / Rezervasyon` sekmeleri; altında mor neon Hero alanı, etkileşimli **Oyunları Keşfet** (`Paramanya`, `Monopoly`, `UNO`, `Catan`) ve **12 İmza Tatlı Menüsü** (`Chimney Cake`, `Monopoly Pastası`, `UNO Cheesecake`, `Hogwarts Brownie`, `Catan Cookie`, `Jenga Cheesecake Bites`, `Pac-Man Donut`, `D&D Lava Cake`, `Lost in Space Tart`, `Chess Cake`, `Among Us Cake`, `Ağlayan Pasta`).
- **İnternetsiz Anlık Kart Animasyonları:** Kişi sayısı (`2`, `3-4`, `5+`), ortam modu (`Kahkahalı`, `Rekabetçi`, `Strateji`, `Hızlı`), tatlı isteği (`Çikolatalı`, `Meyveli`, `Klasik`, `Sürpriz`) seçildikçe veya doğrudan bir oyun/tatlı kartına tıklandıkça uyumlu kartlar anında neon mor/pembe parlama ve büyüme animasyonuyla vurgulanır.
- **Canlı Yapay Zekâ (Play ProBiz AI — Gemini 2.5 Flash):** `"Play ProBiz AI ile Eşleştir"` düğmesine basıldığında yalnızca Play ProBiz menüsüne uygun 5 alanlı yapılandırılmış JSON yanıtı (`secilen_oyun`, `oyun_yorumu`, `tatli_eslesmesi`, `masa_slogani`, `alerjen_uyarisi`) üretilir.
- **Ücretsiz Masa Rezervasyonu & Dijital Masa Bileti:** Kişisel telefon/e-posta istemeden takım takma adı, tarih, saat dilimi (`14:00`–`22:00`), kişi sayısı ve Play ProBiz AI'nin önerdiği oyun/tatlıyla anında `PBZ-XXXX` kodlu dijital masa bileti oluşturur (`Masa Ücreti: ₺0`) ve yerel listede yönetir.
- **Akıllı Hata, Kota ve Çevrimdışı Yedek Yönetimi:** Yükleniyor göstergesi ve düğme kilidi, boş seçim uyarısı, aynı girdiyi tekrar göndermeme (önbellek), kota/hız limiti (`HTTP 429`) durumunda otomatik yeniden deneme ve internetsiz ortamda hazır Play ProBiz JSON yedek cevabı içerir.

### Neden Bu Teknolojiler Seçildi?
- **PyWebView (HTML5/CSS3/JS):** Play ProBiz web sitesinin neon ışık geçişlerini, 12 imza tatlı galerisini ve dijital bilet tasarımını Windows'un yerleşik Edge WebView2 motoruyla tek pencerede ve hafif biçimde sunabildiği için seçildi.
- **Python Standart `urllib.request`:** Ağır harici SDK bağımlılıkları olmadan doğrudan Gemini REST API'sine bağlanarak `.exe` boyutunu küçük tutmak ve PyInstaller paketleme sorunlarını önlemek için seçildi.

---

## Nasıl Çalıştırılır?

### 1. Hazır `.exe` ile (Python Gerektirmez — Windows)
1. `dist\PlayProBiz_AI.exe` dosyasına çift tıklayın.
2. İlk açılışta ekrana gelen **Play ProBiz AI API Anahtarı** paneline ücretsiz Gemini API anahtarınızı (`aistudio.google.com/apikey`) yapıştırıp **Kaydet ve Canlı Başla** düğmesine basın.
   - Anahtarınız **asla koda veya `.exe` içine gömülmez**; yalnızca bilgisayarınızdaki `%APPDATA%\PlayProBiz\config.json` dosyasında saklanır.
   - Anahtar girmeden **Çevrimdışı Demo ile Devam Et** diyerek hazır yedek cevaplarla uygulamayı hemen test edebilirsiniz.

### 2. Kaynak Koddan Çalıştırma
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

---

## Windows `.exe` Olarak Nasıl Paketlenir?

Windows bilgisayarınızda proje klasöründeki **`build_windows.bat`** dosyasına çift tıklayın. İşlem bittiğinde tek dosyalık (`--onefile`) ve konsolsuz (`--noconsole`) uygulama şu konumda oluşur:

```text
dist\PlayProBiz_AI.exe
```

Manuel komut:
```bash
pyinstaller --clean --noconfirm play_probiz.spec
```

---

## Windows "Tanınmayan Uygulama" (SmartScreen) Uyarısı Notu

Kendi derlediğiniz `.exe` dosyasında ücretli ticari dijital imza sertifikası bulunmadığı için Windows Defender SmartScreen ilk çalıştırmada *"Windows bilgisayarınızı korudu — Tanınmayan bir uygulamanın başlamasını engelledi"* uyarısı gösterebilir.

Uygulamayı açmak için:
1. Uyarı penceresinde **"Ek bilgi"** (More info) bağlantısına tıklayın.
2. Açılan **"Yine de çalıştır"** (Run anyway) düğmesine basın.

---

## Testleri Çalıştırma

```bash
pytest -v
```

---

## Bilinen Sınırlar

- **Ücretsiz Gemini API Kotası:** Google AI Studio ücretsiz katmanında dakikalık/günlük istek limiti vardır. Limit aşımında uygulama kısa süre bekleyip otomatik yeniden dener; kota tamamen dolmuşsa Play ProBiz çevrimdışı yedek cevabını gösterir.
- **Yerel Rezervasyon Saklama:** Masa rezervasyonları kişisel veri toplamadan kullanıcının bilgisayarındaki yerel JSON dosyasında saklanır (gerçek sunucu/SMS doğrulaması gerektirmez).
- **Alerjen Uyarısı:** Gösterilen alerjen uyarıları genel bilgilendirme amaçlıdır; ciddi alerjisi olan misafirlerin sipariş öncesi kafe çalışanlarından teyit alması gerekir.
