"""
Play ProBiz — Play ProBiz AI Oyun & Tatlı Eşleştirici + Masa Rezervasyonu

PyWebView ile Play ProBiz web sitesinin premium neon tasarımını tek bir
Windows penceresinde açar; HTML/CSS/JS arayüzü ile Python Gemini motoru
ve yerel rezervasyon yöneticisi arasında köprü kurar.
"""

import os
import sys
from typing import Any, Dict

import webview

from catalog import (
    CRAVING_OPTIONS,
    DESSERTS_CATALOG,
    GAMES_CATALOG,
    MOOD_OPTIONS,
    PLAYER_OPTIONS,
    RESERVATION_SLOTS,
)
from config_manager import (
    clear_api_key,
    get_config_path,
    get_resource_path,
    load_api_key,
    mask_api_key,
    save_api_key,
)
from playprobiz_ai import PlayProBizAIEngine
from reservation_manager import ReservationManager


class PlayProBizAPI:
    """JavaScript arayüzünün çağırabildiği güvenli Python API köprüsü."""

    def __init__(self) -> None:
        self._engine = PlayProBizAIEngine()
        self._reservations = ReservationManager()

    def get_initial_state(self) -> Dict[str, Any]:
        """Arayüz açılışında menü, rezervasyonlar ve API anahtarı durumunu döndürür."""
        api_key = load_api_key()
        return {
            "games": GAMES_CATALOG,
            "desserts": DESSERTS_CATALOG,
            "filters": {
                "players": PLAYER_OPTIONS,
                "moods": MOOD_OPTIONS,
                "cravings": CRAVING_OPTIONS,
                "slots": RESERVATION_SLOTS,
            },
            "reservations": self._reservations.list_reservations(),
            "has_api_key": bool(api_key),
            "masked_api_key": mask_api_key(api_key),
            "config_path": str(get_config_path()),
        }

    def save_api_key(self, raw_key: str) -> Dict[str, Any]:
        """Kullanıcının girdiği API anahtarını yerel ayar dosyasına kaydeder."""
        cleaned = str(raw_key or "").strip()
        if not cleaned:
            return {"ok": False, "message": "Lütfen geçerli bir Gemini API anahtarı girin."}
        if len(cleaned) < 12:
            return {
                "ok": False,
                "message": "Girilen anahtar çok kısa görünüyor. Lütfen anahtarın tamamını kopyalayın.",
            }
        try:
            saved_path = save_api_key(cleaned)
            self._engine.clear_cache()
            return {
                "ok": True,
                "has_api_key": True,
                "masked_api_key": mask_api_key(cleaned),
                "config_path": str(saved_path),
                "message": "API anahtarı bilgisayarındaki yerel ayar dosyasına güvenle kaydedildi.",
            }
        except OSError as exc:
            return {"ok": False, "message": f"Ayar dosyasına yazılamadı: {exc}"}

    def clear_api_key(self) -> Dict[str, Any]:
        """Kayıtlı API anahtarını yerel ayar dosyasından siler."""
        clear_api_key()
        self._engine.clear_cache()
        return {
            "ok": True,
            "has_api_key": False,
            "masked_api_key": "",
            "message": "Kayıtlı API anahtarı temizlendi. Çevrimdışı yedek mod aktif.",
        }

    def match_with_ai(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Play ProBiz AI (Gemini 2.5 Flash) ile oyun ve tatlı eşleştirmesi yapar."""
        api_key = load_api_key()
        force_offline = bool(payload.get("force_offline", False))
        return self._engine.match(
            payload=payload,
            api_key=api_key,
            force_offline=force_offline,
        )

    def create_reservation(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Yeni masa rezervasyonu oluşturur ve dijital bilet döndürür."""
        return self._reservations.create_reservation(payload)

    def cancel_reservation(self, code: str) -> Dict[str, Any]:
        """Kayıtlı masa rezervasyonunu iptal eder."""
        return self._reservations.cancel_reservation(code)


def run_app() -> None:
    """PyWebView penceresini başlatır ve yerel web arayüzünü yükler."""
    index_file = get_resource_path("web/index.html")
    if not index_file.exists():
        raise FileNotFoundError(f"Arayüz dosyası bulunamadı: {index_file}")

    api = PlayProBizAPI()
    webview.create_window(
        title="Play ProBiz — Play ProBiz AI & Masa Rezervasyonu",
        url=index_file.as_uri(),
        js_api=api,
        width=1360,
        height=880,
        min_size=(980, 680),
        background_color="#120826",
        text_select=True,
    )

    gui_backend = "edgechromium" if os.name == "nt" else None
    webview.start(gui=gui_backend, debug=False)


if __name__ == "__main__":
    if "--smoke-check" in sys.argv:
        idx = get_resource_path("web/index.html")
        api_test = PlayProBizAPI()
        state = api_test.get_initial_state()
        assert idx.exists(), f"index.html eksik: {idx}"
        assert len(state["games"]) == 4, "4 oyun yüklenemedi"
        assert len(state["desserts"]) == 12, "12 tatlı yüklenemedi"
        for item in state["games"] + state["desserts"]:
            asset_path = get_resource_path(f"web/{item['image']}")
            assert asset_path.exists(), f"Görsel eksik: {asset_path}"
        assert get_resource_path("web/assets/cafe_hero.jpg").exists(), "Hero görseli eksik"
        print("SMOKE_CHECK_OK")
        sys.exit(0)

    run_app()
