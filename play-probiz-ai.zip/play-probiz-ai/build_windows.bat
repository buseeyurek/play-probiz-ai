@echo off
chcp 65001 >nul
echo ============================================================
echo   Play ProBiz AI | Windows Tek Dosya (.exe) Derleyici
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [HATA] Python bulunamadi. Lutfen python.org adresinden Python 3.10+ kurun.
    pause
    exit /b 1
)

if not exist ".venv" (
    echo [1/3] Sanal ortam (.venv) olusturuluyor...
    python -m venv .venv
)

echo [2/3] Gerekli kutuphaneler (pywebview, pyinstaller) yukleniyor...
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip >nul
pip install -r requirements.txt

echo [3/3] Tek dosya (--onefile) ve konsolsuz (--noconsole) .exe uretiliyor...
pyinstaller --clean --noconfirm play_probiz.spec

if errorlevel 1 (
    echo.
    echo [HATA] Paketleme sirasinda bir sorun olustu.
    pause
    exit /b 1
)

echo.
echo [BASARILI] Windows uygulamasi hazir:
echo   dist\PlayProBiz_AI.exe
echo.
echo Not: API anahtari .exe icine gomulmez; ilk acilista sizden istenir.
pause
