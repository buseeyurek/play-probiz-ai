# -*- mode: python ; coding: utf-8 -*-
"""
Play ProBiz AI — PyInstaller Tek Dosya (--onefile --noconsole) Yapılandırması

web/ klasöründeki tüm HTML, CSS, JS, kafe/oyun/12 imza tatlı görsellerini
ve ikon dosyalarını tek yürütülebilir dosyanın içine gömer.
API anahtarı dosyası (local_config.json) pakete ASLA dahil edilmez.
"""

import os
from PyInstaller.building.build_main import Analysis, PYZ, EXE

project_root = os.path.abspath(SPECPATH)
icon_path = os.path.join(project_root, "web", "assets", "play_probiz.ico")

a = Analysis(
    [os.path.join(project_root, "main.py")],
    pathex=[project_root],
    binaries=[],
    datas=[
        (os.path.join(project_root, "web"), "web"),
    ],
    hiddenimports=[
        "webview",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["pytest", "PIL"],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="PlayProBiz_AI",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    icon=icon_path if os.path.exists(icon_path) else None,
)
